#  BreakIt

## Handbook
* 签名密钥 privat-key(更换电脑时需要导入)

## 命令工具
* 版本升级 agv-tool
* appcast 文件生成 sparkle_support/generate_appcast --link https://breakit.thriller.fun --full-release-notes-url https://breakit.thriller.fun/release_note/ --download-url-prefix https://breakit.thriller.fun/packages/ package_folder_path 

地球不会因你停下来而停止转动\n老板不会因你摸鱼而不挣钱\n所以\n不要犹豫
想成功先发疯，不顾一切向钱冲；
拼一次富三代，拼命才能不失败；
今天睡地板，明天当老板！
