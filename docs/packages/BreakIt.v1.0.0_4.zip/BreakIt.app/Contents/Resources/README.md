#  BreakIt

## Handbook
* 签名密钥 privat-key(更换电脑时需要导入)

## 命令工具
* 版本升级 agv-tool
* appcast 文件生成 sparkle_support/generate_appcast --link https://breakit.thriller.fun --full-release-notes-url https://breakit.thriller.fun/release_note/ --download-url-prefix https://breakit.thriller.fun/packages/ package_folder_path 

地球不会因为你停下来面不转动, 老板不会因为你摸鱼而不挣钱
